from django.contrib import admin
from django.urls import include, path
from rest_framework.routers import DefaultRouter
from restaurant import views

router = DefaultRouter()
router.register(r'tables', views.BookingViewSet, basename='booking-tables')

api_router = DefaultRouter()
api_router.register(r'bookings', views.BookingViewSet, basename='api-bookings')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('restaurant/', include('restaurant.urls')),
    path('restaurant/booking/', include(router.urls)),
    path('api/', include(api_router.urls)),
    path('api/registration/', views.UserRegistrationView.as_view(), name='api-registration'),
    path('auth/', include('djoser.urls')),
    path('auth/', include('djoser.urls.authtoken')),
]
