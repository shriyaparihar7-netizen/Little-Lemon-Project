from datetime import datetime, timezone
from django.test import TestCase
from restaurant.models import Booking, MenuItem


class MenuItemTest(TestCase):
    def test_get_item(self):
        item = MenuItem.objects.create(
            title='IceCream',
            price=8.50,
            inventory=100,
        )
        self.assertEqual(str(item), 'IceCream : 8.5')


class BookingTest(TestCase):
    def test_create_booking(self):
        booking_time = datetime(2026, 11, 20, 19, 0, tzinfo=timezone.utc)
        booking = Booking.objects.create(
            name='Maria Garcia',
            no_of_guests=4,
            booking_date=booking_time,
        )
        self.assertEqual(booking.name, 'Maria Garcia')
        self.assertEqual(booking.no_of_guests, 4)
        self.assertIn('Maria Garcia (4 guests)', str(booking))
