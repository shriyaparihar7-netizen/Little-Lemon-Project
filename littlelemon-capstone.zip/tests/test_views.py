from django.contrib.auth.models import User
from django.urls import reverse
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.test import APITestCase
from restaurant.models import Booking, MenuItem
from restaurant.serializers import MenuItemSerializer


class MenuViewTest(APITestCase):
    def setUp(self):
        MenuItem.objects.create(title='Greek Salad', price='12.50', inventory=20)
        MenuItem.objects.create(title='Bruschetta', price='9.00', inventory=15)

    def test_get_all_menu_items(self):
        response = self.client.get(reverse('menu-items'))
        items = MenuItem.objects.all()
        serializer = MenuItemSerializer(items, many=True)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, serializer.data)

    def test_create_menu_item(self):
        payload = {'title': 'Lemon Tart', 'price': '8.50', 'inventory': 12}
        response = self.client.post(reverse('menu-items'), payload, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(MenuItem.objects.count(), 3)


class BookingViewTest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='tester',
            email='tester@littlelemon.com',
            password='StrongPassword123!',
        )
        self.token = Token.objects.create(user=self.user)
        self.booking = Booking.objects.create(
            name='Elena Rostova',
            no_of_guests=2,
            booking_date='2026-11-22T18:30:00Z',
        )

    def test_unauthenticated_bookings_rejected(self):
        response = self.client.get('/api/bookings/')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_authenticated_booking_crud(self):
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.token.key}')

        # GET list
        list_res = self.client.get('/api/bookings/')
        self.assertEqual(list_res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(list_res.data), 1)

        # POST create
        create_res = self.client.post(
            '/api/bookings/',
            {
                'name': 'Marcus Vance',
                'no_of_guests': 5,
                'booking_date': '2026-11-23T20:00:00Z',
            },
            format='json',
        )
        self.assertEqual(create_res.status_code, status.HTTP_201_CREATED)
        booking_id = create_res.data['id']

        # PUT update
        update_res = self.client.put(
            f'/api/bookings/{booking_id}/',
            {
                'name': 'Marcus Vance',
                'no_of_guests': 6,
                'booking_date': '2026-11-23T20:30:00Z',
            },
            format='json',
        )
        self.assertEqual(update_res.status_code, status.HTTP_200_OK)
        self.assertEqual(update_res.data['no_of_guests'], 6)

        # DELETE remove
        delete_res = self.client.delete(f'/api/bookings/{booking_id}/')
        self.assertEqual(delete_res.status_code, status.HTTP_204_NO_CONTENT)
