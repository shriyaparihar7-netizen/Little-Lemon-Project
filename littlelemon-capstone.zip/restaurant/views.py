from django.contrib.auth.models import User
from django.shortcuts import render
from rest_framework import generics, permissions, viewsets
from .models import Booking, MenuItem
from .serializers import (
    BookingSerializer,
    MenuItemSerializer,
    UserRegistrationSerializer,
)


def index(request):
    """Serve static HTML landing page for Little Lemon."""
    return render(request, 'index.html', {})


class MenuItemsView(generics.ListCreateAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer


class SingleMenuItemView(generics.RetrieveUpdateDestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer


class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]


class UserRegistrationView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer
    permission_classes = [permissions.AllowAny]
