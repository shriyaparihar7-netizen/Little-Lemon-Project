Little Lemon Back-End Developer Capstone Project
==================================================

Test these API endpoints in Insomnia or cURL after running migrations:

1. Static HTML Home Page (Django Templates + Static Assets)
GET  /restaurant/

2. User Registration & Token Authentication
POST /api/registration/
POST /auth/users/
POST /auth/token/login/
POST /restaurant/api-token-auth/
GET  /auth/users/me/

3. Menu Items API (GET, POST, PUT, DELETE)
GET    /restaurant/menu/
POST   /restaurant/menu/
GET    /restaurant/menu/<id>
PUT    /restaurant/menu/<id>
DELETE /restaurant/menu/<id>

4. Table Booking API (Authenticated — GET, POST, PUT, DELETE)
GET    /api/bookings/
POST   /api/bookings/
GET    /api/bookings/<id>
PUT    /api/bookings/<id>
DELETE /api/bookings/<id>

GET    /restaurant/booking/tables/
POST   /restaurant/booking/tables/
GET    /restaurant/booking/tables/<id>
PUT    /restaurant/booking/tables/<id>
DELETE /restaurant/booking/tables/<id>

Quick Start Commands
--------------------
python -m venv venv
source venv/bin/activate   (Windows: venv\Scripts\activate)
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py test
python manage.py runserver

Note for Insomnia Testing:
- For /api/bookings/ and /restaurant/booking/tables/, register via POST /api/registration/,
  generate a token via POST /auth/token/login/, then include the header:
  Authorization: Token <your_auth_token>
